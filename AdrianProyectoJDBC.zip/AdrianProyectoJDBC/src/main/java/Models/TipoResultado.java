package Models;

public enum TipoResultado {
	TODOS,NADIE,ALGUNOS;
}
