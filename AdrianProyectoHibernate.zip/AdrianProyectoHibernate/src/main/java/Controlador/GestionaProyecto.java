package Controlador;

import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import Modelo.Evento;
import Modelo.Moto;
import Modelo.Ruta;
import Modelo.Taller;
import Modelo.Usuario;
import Repositorio.EventoDao;
import Repositorio.MotoDao;
import Repositorio.RutaDao;
import Repositorio.TallerDao;
import Repositorio.UsuarioDao;
import Util.HibernateUtil;


public class GestionaProyecto {
	
	private static final Logger logger =LogManager.getLogger(GestionaProyecto.class);

	public static void main(String[] args) {
		// ---------- DAOs ----------
        UsuarioDao usuarioDao = new UsuarioDao();
        MotoDao motoDao = new MotoDao();
        EventoDao eventoDao = new EventoDao();
        TallerDao tallerDao = new TallerDao();
        RutaDao rutaDao = new RutaDao();

        logger.info("=== INICIO PRUEBAS HIBERNATE ===");

        // ---------- 1. Crear Usuario ----------
        Usuario usuario = new Usuario("Adrian", "Prueba", "adrian@test.com", "usuario");
        usuarioDao.create(usuario);
        logger.info("Usuario creado con ID: {}", usuario.getIdUsuario());

        // ---------- 2. Crear Moto ----------
        Moto moto = new Moto();
        moto.setMarca("Yamaha");
        moto.setModelo("MT-07");
        moto.setMatricula("1234ABC");
        moto.setCilindrada(689);
        moto.setItvFecha(LocalDate.now().plusYears(1));
        moto.setQrCodigo("QR-TEST-001");
        moto.setPropietario(usuario);

        motoDao.create(moto);
        logger.info("Moto creada con ID: {}", moto.getIdMoto());

        // ---------- 3. Crear Taller ----------
        Usuario usuarioTaller = new Usuario("Taller", "Oficial", "taller@test.com", "taller");
        usuarioDao.create(usuarioTaller);

        Taller taller = new Taller();
        taller.setNombreTaller("Taller Oficial Yamaha");
        taller.setDireccion("Calle Principal 123");
        taller.setTelefono("600123456");
        taller.setCif("B12345678");
        taller.setEstadoVerificacion(true);
        taller.setUsuario(usuarioTaller);

        tallerDao.create(taller);
        logger.info("Taller creado con ID: {}", taller.getIdTaller());

        // ---------- 4. Crear Evento ----------
        Evento evento = new Evento();
        evento.setTipoEvento("Mantenimiento");
        evento.setDescripcion("Cambio de aceite y filtros");
        evento.setFechaEvento(LocalDate.now());
        evento.setKm(12000);
        evento.setEsValidado(true);
        evento.setFechaValidacion(LocalDate.now());
        evento.setMoto(moto);
        evento.setUsuarioCreador(usuario);
        evento.setTallerValidador(taller);

        eventoDao.create(evento);
        logger.info("Evento creado con ID: {}", evento.getIdEvento());

        // ---------- 5. Crear Ruta ----------
        Ruta ruta = new Ruta();
        ruta.setNombre("Ruta Sierra");
        ruta.setDistanciaKm(180);
        ruta.setDificultad("Media");
        ruta.setTipoTerreno("Asfalto");
        ruta.setDescripcion("Ruta de curvas por la sierra");
        ruta.setEsOficial(true);

        ruta.setMotos(new ArrayList<>());
        ruta.getMotos().add(moto);

        rutaDao.create(ruta);
        logger.info("Ruta creada con ID: {}", ruta.getIdRuta());

        // ---------- 6. Asociar Moto - Ruta ----------
        moto.setRutas(new ArrayList<>());
        moto.getRutas().add(ruta);
        motoDao.update(moto);

        logger.info("Ruta asociada a la moto");

        // ---------- 7. Comprobaciones ----------
        logger.info("Total usuarios: {}", usuarioDao.getAll().size());
        logger.info("Total motos: {}", motoDao.getAll().size());
        logger.info("Total eventos: {}", eventoDao.getAll().size());
        logger.info("Total talleres: {}", tallerDao.getAll().size());
        logger.info("Total rutas: {}", rutaDao.getAll().size());

        // ---------- FIN ----------
        HibernateUtil.shutdown();
        logger.info("=== FIN PRUEBAS ===");
    }
}
