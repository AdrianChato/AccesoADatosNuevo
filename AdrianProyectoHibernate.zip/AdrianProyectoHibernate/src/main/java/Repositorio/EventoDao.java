package Repositorio;

import Modelo.Evento;
import Util.AbstractDao;

public class EventoDao extends AbstractDao<Evento> {

    public EventoDao() {
        setClase(Evento.class);
    }
}