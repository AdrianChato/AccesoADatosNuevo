package Repositorio;

import Modelo.Ruta;
import Util.AbstractDao;

public class RutaDao extends AbstractDao<Ruta>{

	public RutaDao() {
        setClase(Ruta.class);
    }
}
