package Repositorio;

import Modelo.Usuario;
import Util.AbstractDao;

public class UsuarioDao extends AbstractDao<Usuario> {

    public UsuarioDao() {
        setClase(Usuario.class);
    }
}
