package Repositorio;

import Modelo.Moto;
import Util.AbstractDao;

public class MotoDao extends AbstractDao<Moto> {

    public MotoDao() {
        setClase(Moto.class);
    }
}
